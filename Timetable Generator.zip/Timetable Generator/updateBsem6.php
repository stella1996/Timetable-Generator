<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_register = "127.0.0.1";
$database_register = "sam";
$username_register = "steffy";
$password_register = "123";
$register = mysql_pconnect($hostname_register, $username_register, $password_register) or trigger_error(mysql_error(),E_USER_ERROR); 
$db=mysql_select_db($database_register,$register) or die("Failed to connect to MySQL: " . mysql_error());


if(mysqli_connect_errno($register))
{
echo "failed to connect:" .mysqli_connect_error();
}


function NewUser()
{    
$Timimgs =$_POST['cell1'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=09.00";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell2'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=09.00";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell3'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=09.00";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell4'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=09.00";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell5'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=09.00";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell6'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=09.00";
$data = mysql_query ($query)or die(mysql_error());


$Timimgs =$_POST['cell8'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=09.50";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell9'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=09.50";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell10'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=09.50";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell11'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=09.50";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell12'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=09.50";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell13'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=09.50";
$data = mysql_query ($query)or die(mysql_error());

$Timimgs =$_POST['cell15'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=10.40";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell16'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=10.40";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell17'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=10.40";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell18'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=10.40";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell19'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=10.40";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell20'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=10.40";
$data = mysql_query ($query)or die(mysql_error());
$Timimgs =$_POST['cell22'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=11.30";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell23'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=11.30";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell24'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=11.30";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell25'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=11.30";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell26'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=11.30";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell27'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=11.30";
$data = mysql_query ($query)or die(mysql_error());

$Timimgs =$_POST['cell29'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=01.20";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell30'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=01.20";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell31'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=01.20";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell32'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=01.20";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell33'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=01.20";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell34'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=01.20";
$data = mysql_query ($query)or die(mysql_error());
$Timimgs =$_POST['cell36'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=02.10";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell37'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=02.10";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell38'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=02.10";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell39'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=02.10";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell40'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=02.10";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell41'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=02.10";
$data = mysql_query ($query)or die(mysql_error());
$Timimgs =$_POST['cell43'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=03.00";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell44'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=03.00";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell45'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=03.00";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell46'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=03.00";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell47'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=03.00";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell48'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=03.00";
$data = mysql_query ($query)or die(mysql_error());

$Timimgs =$_POST['cell50'];
$query = "update csebtable6 Set Timimgs='$Timimgs' where Timimgs=03.50";
$data = mysql_query ($query)or die(mysql_error());
$Monday =$_POST['cell51'];
$query = "update csebtable6 Set Monday='$Monday' where Timimgs=03.50";
$data = mysql_query ($query)or die(mysql_error());
$Tuesday =$_POST['cell52'];
$query = "update csebtable6 Set Tuesday='$Tuesday' where Timimgs=03.50";
$data = mysql_query ($query)or die(mysql_error());
$wednesday =$_POST['cell53'];
$query = "update csebtable6 Set wednesday='$wednesday' where Timimgs=03.50";
$data = mysql_query ($query)or die(mysql_error());
$thrusday =$_POST['cell54'];
$query = "update csebtable6 Set thursday='$thrusday' where Timimgs=03.50";
$data = mysql_query ($query)or die(mysql_error());
$friday =$_POST['cell55'];
$query = "update csebtable6 Set friday='$friday' where Timimgs=03.50";
$data = mysql_query ($query)or die(mysql_error());
}



if(isset($_POST['submit']))
{
	NewUser();
}
?>
<!DOCTYPE html>
<html>

<head>
<title>CSE "B" Sem 6</title>

<style>
table, th, td {
     border: 2px solid black;
	 background-color:#00CCFF;
	  color:#000000;
	  margin-top:30px;
	  margin-right:80px;
	  margin-left:280px;
	  margin-bottom:30px;
	   padding:10px;
	   border-collapse:collapse;
	   border-color:#ffffff;

}
th
{
background-color:#003399;
	border-color:#ffffff;

color:white;
}
td {
    border:thin #4caf50;
	background-color:#4caf50;
		border-color:#ffffff;

    border-style:solid ;
    text-align:center;
    padding: 8px;
	height:25px;



h1
{
 margin-top:20px;
 }
</style>
</head>
<body>
<?php
$servername = "127.0.0.1";
$username = "steffy";
$password = "123";
$dbname = "sam";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

        
echo "<h1 style=text-align:center;margin-left:0px>TimeTable </h1>";


$sql = "SELECT  * FROM csebtable6";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
echo "<left><table style=margin-left:410px><tr><th>Timimgs</th><th>Monday</th><th>Tuesday</th><th>Wednesday</th><th>Thursday</th><th>Friday</th></tr></left>";     // output data of each row
     while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Timimgs"]. "</td><td>" . $row["Monday"]. "</td><td>" . $row["tuesday"]. "</td>
<td>" . $row["wednesday"]. "</td><td>" . $row["thursday"]. "</td><td>" . $row["friday"]. "</td></tr>";
     }
     echo "</table>";
} else {
     echo "0 results";
}

$conn->close();
?>
<a href="new 1.html"><img src="home.png" height="42" width="56" style="float:right"></a>

</body>
</html>
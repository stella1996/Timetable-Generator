<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_register = "127.0.0.1";
$database_register = "sam";
$username_register = "steffy";
$password_register = "123";
$register = mysql_pconnect($hostname_register, $username_register, $password_register) or trigger_error(mysql_error(),E_USER_ERROR); 
$db=mysql_select_db($database_register,$register) or die("Failed to connect to MySQL: " . mysql_error());


if(mysqli_connect_errno($register))
{
echo "failed to connect:" .mysqli_connect_error();
}

function NewUser()
{    
    $ClassAdvisor=$_POST['classadvisor'];
	$FacultyAdvisor=$_POST['FACULTYadvisor'];
    $Semester=$_POST['semester'];

    $Representative=$_POST['representative'];
	  $ClassName=$_POST['classname'];
	    $Classemailid=$_POST['ClassEmailid'];
		$query = "INSERT INTO classb4(ClassAdvisor,FacultyAdvisor,Semester,Representative,Classemailid	,ClassName) VALUES ('$ClassAdvisor','$FacultyAdvisor','$Semester', '$Representative','$Classemailid','$ClassName')";
    $data = mysql_query ($query)or die(mysql_error());
$Timings=$_POST['cell1'];
    $Monday =$_POST['cell2'];
    $Tuesday =$_POST['cell3'];
    $wednesday =$_POST['cell4'];
    $thrusday =$_POST['cell5'];
	 $friday =$_POST['cell6'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	 $Timings=$_POST['cell8'];
    $Monday =$_POST['cell9'];
    $Tuesday =$_POST['cell10'];
    $wednesday =$_POST['cell11'];
    $thrusday =$_POST['cell12'];
	 $friday =$_POST['cell13'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	 $Timings=$_POST['cell15'];
    $Monday =$_POST['cell16'];
    $Tuesday =$_POST['cell17'];
    $wednesday =$_POST['cell18'];
    $thrusday =$_POST['cell19'];
	 $friday =$_POST['cell20'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	 $Timings=$_POST['cell22'];
    $Monday =$_POST['cell23'];
    $Tuesday =$_POST['cell24'];
    $wednesday =$_POST['cell25'];
    $thrusday =$_POST['cell26'];
	 $friday =$_POST['cell27'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	 $Timings=$_POST['cell29'];
    $Monday =$_POST['cell30'];
    $Tuesday =$_POST['cell31'];
    $wednesday =$_POST['cell32'];
    $thrusday =$_POST['cell33'];
	 $friday =$_POST['cell34'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	 $Timings=$_POST['cell36'];
    $Monday =$_POST['cell37'];
    $Tuesday =$_POST['cell38'];
    $wednesday =$_POST['cell39'];
    $thrusday =$_POST['cell40'];
	 $friday =$_POST['cell41'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	 $Timings=$_POST['cell43'];
    $Monday =$_POST['cell44'];
    $Tuesday =$_POST['cell45'];
    $wednesday =$_POST['cell46'];
    $thrusday =$_POST['cell47'];
	 $friday =$_POST['cell48'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	 $Timings=$_POST['cell50'];
    $Monday =$_POST['cell51'];
    $Tuesday =$_POST['cell52'];
    $wednesday =$_POST['cell53'];
    $thrusday =$_POST['cell54'];
	 $friday =$_POST['cell55'];
	$query = "INSERT INTO csebtable4(Timimgs,Monday,Tuesday,wednesday,thursday,friday) VALUES ('$Timings','$Monday','$Tuesday', '$wednesday','$thrusday','$friday')";
    $data = mysql_query ($query)or die(mysql_error());
	
	
	
	

}



if(isset($_POST['submit']))
{
	NewUser();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>CSE "B" Sem 4</title>

<style>
table, th, td {
     border: 2px solid black;
	 background-color:#00CCFF;
	  color:#000000;
	  margin-top:30px;
	  margin-right:80px;
	  margin-left:280px;
	  margin-bottom:30px;
	   padding:10px;
	   border-collapse:collapse;
	   border-color:#ffffff;

}
th
{
background-color:#003399;
	border-color:#ffffff;

color:white;
}
td {
    border:thin #4caf50;
	background-color:#4caf50;
		border-color:#ffffff;

    border-style:solid ;
    text-align:center;
    padding: 8px;
	height:25px;



h1
{
 margin-top:20px;
 }
</style>
</head>
<body>
<a href="new 1.html"><img src="home.png" height="42" width="56" style="float:right"></a>

<?php
$servername = "127.0.0.1";
$username = "steffy";
$password = "123";
$dbname = "sam";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT * from classb4";
$result = $conn->query($sql);
	//echo '<span style="color:white;text-align:center">YOUR REGISTRATION IS COMPLETED</span>';

echo "<h1 style=text-align:center;margin-left:0px>Class Details </h1>";
if ($result->num_rows > 0) {
     // output data of each row
echo "<table style=text-align:center;margin-left:310px><tr><th>ClassAdvisor</th><th>FacultyAdvisor</th><th>Semester</th><th>Representative</th><th>Classemailid</th><th>ClassName</th></tr>";

     while($row = $result->fetch_assoc()) {
	          echo "<tr><td>" . $row["ClassAdvisor"]. "</td><td>" . $row["FacultyAdvisor"]. "</td><td>" . $row["Semester"]. "</td><td>" . $row["Representative"]. "</td><td>" . $row["Classemailid"]. "</td><td>" . $row["ClassName"]. "</td></tr>";
 }
     echo "</table>";
} else {
     echo "0 results";
}
        
echo "<h1 style=text-align:center;margin-left:0px>TimeTable </h1>";


$sql = "SELECT  * FROM csebtable4";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     echo "<left><table style=margin-left:410px><tr><th>Timimgs</th><th>Monday</th><th>Tuesday</th><th>Wednesday</th><th>Thursday</th><th>Friday</th></tr></left>";
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<tr><td>" . $row["Timimgs"]. "</td><td>" . $row["Monday"]. "</td><td>" . $row["tuesday"]. "</td><td>" . $row["wednesday"]. "</td><td>" . $row["thursday"]. "</td><td>" . $row["friday"]. "</td></tr>";
     }
     echo "</table>";
} else {
     echo "0 results";
}

$conn->close();
?>

</body>
</html>

